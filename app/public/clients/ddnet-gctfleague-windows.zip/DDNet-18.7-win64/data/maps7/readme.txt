Maps in this directory are created using the map_convert_07 tool for
server compatibility with Teeworlds 0.7 clients
